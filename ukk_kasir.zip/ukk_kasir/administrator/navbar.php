<div class="card mt-5">
	<div class="card-body">
		<a href="index.php" class="btn btn-success">Beranda</a>
		<a href="data_barang.php" class="btn btn-success">Data Barang</a>
		<a href="pembelian.php" class="btn btn-success">Pembelian</a>
		<!--<a href="stok_barang.php" class="btn btn-success">Stok Barang</a>-->
		<a href="data_pengguna.php" class="btn btn-success">Data Pengguna</a>
		<a href="../logout.php" class="btn btn-danger">Keluar</a>
	</div>
</div>